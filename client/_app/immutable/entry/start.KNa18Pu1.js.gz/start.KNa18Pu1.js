import{a as t}from"../chunks/entry.C2JGAoL1.js";export{t as start};
